package Questao4;

public class Result {

	private String speciesName;
	private int amount;
	
	public Result(String speciesName, int amount) {
		this.speciesName = speciesName;
		this.amount = amount;
	}
	
	public String getSeciesName() {
		return speciesName;
	}
	
	public int getAmount () {
		return amount;
	}

}
