package Questao4;


public class Implementacao implements Tools, Animal{

	@Override
	public String getSpiciesName() {
		return null;
	}

	@Override
	public String getAnimalName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Animal[] filterSpecies(Animal[] list, String speciesFilter) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String[] speciesCassification(Animal[] list) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
