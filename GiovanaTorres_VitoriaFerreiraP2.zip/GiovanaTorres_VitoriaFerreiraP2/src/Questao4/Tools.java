package Questao4;

public interface Tools {

	public Animal[] filterSpecies(Animal[] list, String speciesFilter);
	public String[] speciesCassification (Animal[] list);
}
