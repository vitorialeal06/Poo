package Questao4;

public interface Animal {

	public String getSpiciesName();
	public String getAnimalName();
	

}
