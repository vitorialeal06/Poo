package Questao1;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		
	}

}
