package Questao1;

public interface AccountChange {

	public String getCPF();
	public float getChangeValue();

}
