package Questao1;

public interface BankOperations {
	public Costumer findCostumer (Costumer allCostumers[], String cpf); 
}
