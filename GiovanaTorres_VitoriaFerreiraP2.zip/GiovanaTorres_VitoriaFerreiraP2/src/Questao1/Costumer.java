package Questao1;

public class Costumer implements BankOperations, AccountChange{
	private  String clientCPF;
	private float balance;
	Costumer allCostumers[];
	
	public Costumer (String cpf, float balance) {
		this.clientCPF = cpf;
		this.balance = balance;
	}
	
	public String getClientCPF() {
		return clientCPF;
	}
	
	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}
	
	@Override
	public String getCPF() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public float getChangeValue() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public Costumer findCostumer (Costumer allCostumers[], String cpf) {
		for (int i = 0; i < allCostumers.length; i++) {
			if (allCostumers[i].equals(cpf)) {
				return allCostumers[i];
			}
			else 
				return null;
		}
		return null; //arrumar depois
	}
	
	public Costumer[] Correntista (Costumer allCostumers[], String cpf) {
		return allCostumers;
	}
	
	public 
	

}
