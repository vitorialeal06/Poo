package Questao2;
import java.util.ArrayList;

class ComplexBugetItem extends BudgetItem {
	float soma = 0;
	
	public ComplexBugetItem(String history, float value) {
		super(history, value);
	}
	
	public BudgetItem findItem(String nome) {
		for (int i = 0; i < orcamento2.size(); i++) {
			if (orcamento.get(i).getHistory() == nome) {
				return orcamento.get(i);
			}
			else
				return null;
		}
	}

	ArrayList<BudgetItem> orcamento = new ArrayList<BudgetItem>();
	ArrayList<ComplexBugetItem> orcamento2 = new ArrayList<ComplexBugetItem>();
	
	BudgetItem entrada = new BudgetItem(getHistory(), getValue());
	orcamento.add(entrada);
    
}
