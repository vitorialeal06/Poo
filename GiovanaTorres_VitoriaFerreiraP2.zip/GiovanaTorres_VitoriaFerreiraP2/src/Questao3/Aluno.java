package Questao3;
import java.util.ArrayList;
import java.util.Date;

public class Aluno extends Pessoa {
	
	private String curso;
	private int periodo;
	ArrayList<String> dps = new ArrayList<String>();
	private Date previsaoDeFormatura;
	
	public Aluno(String nome, String nusp, Date dataIngresso, String curso, int periodo, Date previsaoDeFormatura, ArrayList<String> dps) {
		super(nome, nusp, dataIngresso);
		this.curso = curso;
		this.periodo = periodo;
		this.previsaoDeFormatura = previsaoDeFormatura;
		this.dps = dps;
	}
	
	public String getCurso() {
		return curso;
	}
	public void setCurso(String curso) {
		this.curso = curso;
	}
	public int getPeriodo() {
		return periodo;
	}
	public void setPeriodo(int periodo) {
		this.periodo = periodo;
	}
	public Date getPrevisaoDeFormatura() {
		return previsaoDeFormatura;
	}
	public void setPrevisaoDeFormatura(Date previsaoDeFormatura) {
		this.previsaoDeFormatura = previsaoDeFormatura;
	}
}
