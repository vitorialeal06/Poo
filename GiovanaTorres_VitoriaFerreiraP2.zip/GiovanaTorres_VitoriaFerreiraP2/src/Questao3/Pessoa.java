package Questao3;
import java.util.Date;

public class Pessoa {
	
	private String nome;
	private String nusp;
	private Date dataIngresso;
	
	public Pessoa(String nome, String nusp, Date dataIngresso) {
		this.nome = nome;
		this.nusp = nusp;
		this.dataIngresso = dataIngresso;
	}
	
	int aleatorio = (int) (Math.random() * 1001);
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getNusp() {
		return nusp;
	}
	
	public void setNusp(String aleatorio) {
		String nusp = String.valueOf(aleatorio);
		this.nusp = aleatorio;
	}
	public Date getDataIngresso() {
		return dataIngresso;
	}
	public void setDataIngresso(Date dataIngresso) {
		this.dataIngresso = dataIngresso;
	}

	public void ordenarDataIngresso() {
		// TODO Auto-generated method stub
		
	}

}
