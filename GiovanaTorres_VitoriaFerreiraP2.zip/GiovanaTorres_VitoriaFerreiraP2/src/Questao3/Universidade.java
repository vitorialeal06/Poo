package Questao3;

import java.util.Date;

public class Universidade extends Pessoa implements GerenciadorDePessoas{

	public Universidade(String nome, String nusp, Date dataIngresso) {
		super(nome, nusp, dataIngresso);
	}

	@Override
	public void ordenarDataIngresso() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void areasSemelhantes() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int emFerias() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void jubilados() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean periodoIdeal(String id) {
		// TODO Auto-generated method stub
		return false;
	}
	
	

	//int p = (int) (Math.random() * 10); para gerar id
	
	

}
