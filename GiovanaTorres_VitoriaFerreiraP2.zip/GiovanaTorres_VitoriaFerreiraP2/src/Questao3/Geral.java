package Questao3;

import java.util.Date;

public class Geral extends Funcionario{

	private String funcao;
	private boolean ferias;
	
	public Geral(String nome, String nusp, Date dataIngresso, int salario, int anos, String funcao, boolean ferias) {
		super(nome, nusp, dataIngresso, salario, anos);
		this.ferias = ferias;
		this.funcao = funcao;
	}
	
	public String getFuncao() {
		return funcao;
	}
	public void setFuncao(String funcao) {
		this.funcao = funcao;
	}
	public boolean isFerias() {
		return ferias;
	}
	public void setFerias(boolean ferias) {
		this.ferias = ferias;
	}
}
